function Chessman(type = null) {
	if(type) {
		// Quan
		this.score=10;
		this.name='quan';
	}
	else // Dan
	{
		this.name='dan';
		this.score=1;
	}
	return this;
}
function Square(type = null) {
	this.totalValue=function() {
		var total = 0;
		for (var i = 0; i < this.array.length; i++) {
			total += this.array[i].score;
		}
		return total;
	}
	this.emty = function() { //Lam trong o
		this.array=[];
	}
	this.add = function() { //Them 1 quan
		var chessman = new Chessman();
		this.array.push(chessman);
	}
	this.array = [];
	if (type) {
		var chessman = new Chessman(true);
		this.array.push(chessman);

	}
	else {
		for (var i = 0; i < 5; i++) {
			var chessman = new Chessman();
			this.array.push(chessman);
		}
	}
	
	return this;
}
function Player(name) {
	this.name = name;
	this.array=[];

}
function Chess(name1, name2) {
	this.banco = [
		[new Square(true),new Square(),new Square(),new Square(),new Square(),new Square(),new Square(true)],
		[new Square(),new Square(),new Square(),new Square(),new Square()]
	];
	this.player1 = new Player(name1);
	this.player2 = new Player(name2);
	this.move = function(x, y, d, player) {
		// if (player==1) {
		// 	if (x!=0)
		// 		return null;
			//Chon dung vi tri, bat dau rai quan
		this.banco[x][y].emty(); //Lam trong o duoc chon
		var current = {x:x,y:y,d:d};
		for (var i = 0; i < this.banco[x][y].array.length; i++) {
			current = next(current);
			this.banco[current.x][current.y].add();
		}
		if(conluot(current.x,current.y,current.d))
		{
			move(current.x,current.y,current.d,player);
		}
		else
		{
			// xet tinh diem
		}
	}
	this.conluot = function(x,y,d) // return true false
	{

	}
	this.next = function(array) {
		if (array.x==0 && array.y==0 && array.d==false) { 
			return result = {x:1,y:0,d:true};
		}
		if (array.x==1 && array.y==0 && array.d==false) { 
			return result = {x:0,y:0,d:true};
		}
		if (array.x==0 && array.y==6 && array.d==true) { 
			return result = {x:0,y:4,d:false};
		}
		if (array.x==1 && array.y==4 && array.d==true) { 
			return result = {x:0,y:7,d:false};
		}
		if (array.d) {
			return result = {x: array.x, y: array.y +1, d: array.d};
		} else {
			return result = {x: array.x, y: array.y -1, d: array.d};
		}
	}

}