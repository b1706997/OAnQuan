function Chessman(type = null) {
	if(type) {
		// Quan
		this.value=10;
		this.name='quan';
	}
	else // Dan
	{
		this.name='dan';
		this.value=1;
	}
	return this;
}
function Square(type = null) {
	this.totalValue=function() {
		var total = 0;
		for (var i = 0; i < this.array.length; i++) {
			total += this.array[i].value;
		}
		return total;
	}
	this.empty = function() { //Lam trong o duoc chon de rai quan
		this.array=[];
	}
	this.add = function() { //Them 1 quan
		var chessman = new Chessman();
		this.array.push(chessman);
	}
	this.containChess = function()
	{
		if(this.array.length==0)
			return false;
		else
			return true;
	}
	this.array = [];
	if (type) {
		var chessman = new Chessman(true);
		this.array.push(chessman);
	}
	else {
		for (var i = 0; i < 5; i++) {
			var chessman = new Chessman();
			this.array.push(chessman);
		}
	}
	
	return this;
}
function Player(name) {
	this.name = name;
	this.array=[];
	this.score = function()
	{
		var totalScore=0;
		for(var i=0;i<this.array.length;i++)
		{
			totalScore += this.array[i].value;
		}
		return totalScore;
	}

}
function Chess(name1, name2) {
	this.banco = [
		[new Square(true),new Square(),new Square(),new Square(),new Square(),new Square(),new Square(true)],
		[new Square(),new Square(),new Square(),new Square(),new Square()]
	];
	// this.currentPlayer = this.player1;
	this.player1 = new Player(name1);
	this.player2 = new Player(name2);
	this.move = function(x, y, d, player) {
		var currentPlayer;
		if (player==1)
			currentPlayer = this.player1;
		else
			currentPlayer = this.player2;
		this.banco[x][y].empty(); //Lam trong o duoc chon
		var current = {x:x,y:y,d:d}; // doi tuong current chua 3 thuoc tinh: x,y la toa do ban co; d la huong di chuyen
		var result;
		for (var i = 0; i < this.banco[x][y].array.length; i++) {
			current = next(current);
			this.banco[current.x][current.y].add();
		}
		var next = this.next(current);
		if(this.conluot(next.x,next.y,next.d))
		{
			this.move(next.x,next.y,next.d,player);
		}
		else
		{
			// xet tinh diem
			var nextnext = this.next(next);
			nextnext = this.banco[nextnext.x][nextnext.y];
			if(nextnext.containChess())
			{
				// an
				for(var i=0;i<nextnext.array.length;i++)
				{
					currentPlayer.array.push(nextnext.array[i]);
				}
				nextnext.empty();
			}
		}
	}
	this.conluot = function(x,y,d) // return true false
	{
		if((x==0 && y==0) || (x==0 && y==6))
		{// vi tri hai dau
			if(this.banco[x][y].containChess())
				return false;
		}
		// var next = {x:x,y:y,d:d};
		// var nextnext = next(next);
		if(!this.banco[x][y].containChess())
			return false;


		return true;
	}
	this.next = function(array) {
		if (array.x==0 && array.y==0 && array.d==false) { 
			return result = {x:1,y:0,d:true};
		}
		if (array.x==1 && array.y==0 && array.d==false) { 
			return result = {x:0,y:0,d:true};
		}
		if (array.x==0 && array.y==6 && array.d==true) { 
			return result = {x:1,y:4,d:false};
		}
		if (array.x==1 && array.y==4 && array.d==true) { 
			return result = {x:0,y:7,d:false};
		}
		if (array.d) {
			return result = {x: array.x, y: array.y +1, d: array.d};
		} else {
			return result = {x: array.x, y: array.y -1, d: array.d};
		}
	}

}